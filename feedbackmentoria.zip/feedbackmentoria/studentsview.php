<div class="acoes">
	<div class="panel panel-default">
	  <div class="panel-heading">Ações</div>
	  <div class="panel-body">
	  	<div class="overflow"></div>
	  	<hr/>
	  	<form class="form-submit">
	  		<label>Adicionar ações</label>
			<input type="text" name="action-name" />
			<input type="button" class="btn btn-default" onClick="actionCreate($(this))" value="Adicionar" />
		</form>
	  </div>
	</div>
</div>