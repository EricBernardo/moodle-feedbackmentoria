<p>
	<form id="filter">
		<div class="form-control select-teachers">
			<label>Professor</label>
			<select class="select" name="teacher"></select>
		</div>
		<div class="form-control select-students">
			<label>Aluno</label>
			<select class="select" name="student"></select>
		</div>
		<div class="form-control button-filter">		
			<input type="button" class="btn btn-default" onClick="onSubmit()" value="Pesquisar" />
		</div>
	</form>
</p>