<p>
	<form id="filter">
		<div class="form-control select-teachers">
			<label>Professor</label>
			<select class="select" name="teacher" onchange="onSubmit()"></select>
		</div>
		<div class="form-control select-students">
			<label>Aluno</label>
			<select class="select" name="student" onchange="onSubmit()"></select>
		</div>
	</form>
</p>