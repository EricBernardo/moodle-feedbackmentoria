<?php
echo '<h3><p>' . ($moduleinstance->name) . '</p></h3>';
echo '<p>' . ($moduleinstance->intro) . '</p>';