<div class="feedback">
	<div class="panel panel-default">
	  <div class="panel-heading">Feedback</div>
	  <div class="panel-body">
		<div class="overflow"></div>
		<hr/>
		<form id="form-comment" class="form-submit" action="javascript:commentCreate()">
			<label>Adicionar comentário</label>
			<textarea name="comment"></textarea>
			<input type="submit" class="btn btn-default" value="Enviar" />
		</form>
	  </div>
	</div>
</div>